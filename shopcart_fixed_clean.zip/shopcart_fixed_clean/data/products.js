export const products = [
  {
    "id": 1,
    "name": "Prestigio Heritage",
    "brand": "Prestigio",
    "category": "Watches",
    "price": 539,
    "rating": 4.5,
    "image": "/images/products/prestigio_heritage.jpg"
  },
  {
    "id": 2,
    "name": "Chronox Chrono",
    "brand": "Chronox",
    "category": "Watches",
    "price": 264,
    "rating": 4.8,
    "image": "/images/products/chronox_chrono.jpg"
  },
  {
    "id": 3,
    "name": "Aurelia Midnight",
    "brand": "Aurelia",
    "category": "Watches",
    "price": 364,
    "rating": 4.6,
    "image": "/images/products/aurelia_midnight.jpg"
  },
  {
    "id": 4,
    "name": "New Balance Runner",
    "brand": "New Balance",
    "category": "Sneakers",
    "price": 89,
    "rating": 4.4,
    "image": "/images/products/new_balance_runner.jpg"
  },
  {
    "id": 5,
    "name": "New Balance Flex",
    "brand": "New Balance",
    "category": "Sneakers",
    "price": 84,
    "rating": 4.7,
    "image": "/images/products/new_balance_flex.jpg"
  },
  {
    "id": 6,
    "name": "Adidas Glide",
    "brand": "Adidas",
    "category": "Sneakers",
    "price": 149,
    "rating": 4.9,
    "image": "/images/products/adidas_glide.jpg"
  },
  {
    "id": 7,
    "name": "UrbanPack Explorer",
    "brand": "UrbanPack",
    "category": "Backpacks",
    "price": 109,
    "rating": 4.3,
    "image": "/images/products/urbanpack_explorer.jpg"
  },
  {
    "id": 8,
    "name": "North Peak Ranger",
    "brand": "North Peak",
    "category": "Backpacks",
    "price": 94,
    "rating": 4.3,
    "image": "/images/products/north_peak_ranger.jpg"
  },
  {
    "id": 9,
    "name": "Nomadic City",
    "brand": "Nomadic",
    "category": "Backpacks",
    "price": 79,
    "rating": 4.7,
    "image": "/images/products/nomadic_city.jpg"
  },
  {
    "id": 10,
    "name": "AudioPro Studio",
    "brand": "AudioPro",
    "category": "Headphones",
    "price": 109,
    "rating": 4.8,
    "image": "/images/products/audiopro_studio.jpg"
  }
];
