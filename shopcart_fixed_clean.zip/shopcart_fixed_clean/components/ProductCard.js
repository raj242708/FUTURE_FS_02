import { useContext } from 'react'
import { ShopContext } from '../context/ShopContext'

export default function ProductCard({ product }) {
  const { addToCart } = useContext(ShopContext)
  return (
    <div className="card p-4 flex flex-col">
      <div className="aspect-square w-full overflow-hidden rounded-xl bg-white">
        <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
      </div>
      <h3 className="font-semibold mt-3">{product.name}</h3>
      <p className="text-sm text-neutral-500">{product.brand} • {product.category}</p>
      <div className="mt-2 flex items-center justify-between">
        <div>
          <div className="text-lg font-bold">${product.price}</div>
          <div className="text-xs text-yellow-600">⭐ {product.rating}</div>
        </div>
        <button className="btn-primary" onClick={() => addToCart(product)}>Add to Cart</button>
      </div>
    </div>
  )
}
