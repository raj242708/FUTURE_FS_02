import Link from 'next/link'
import { useContext } from 'react'
import { ShopContext } from '../context/ShopContext'

export default function Navbar() {
  const { cart } = useContext(ShopContext)
  const count = cart.reduce((t, i) => t + (i.qty || 1), 0)
  return (
    <header className="sticky top-0 z-40 bg-white/80 backdrop-blur border-b border-neutral-200">
      <div className="container h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 font-bold text-lg">
          <span className="w-8 h-8 grid place-items-center rounded-full bg-blue-600 text-white">S</span>
          <span>Shopcart</span>
        </Link>
        <nav className="flex items-center gap-4 text-sm">
          <Link className="hover:underline" href="/">Home</Link>
          <Link className="hover:underline" href="/cart">Cart ({count})</Link>
          <Link className="btn-primary" href="/checkout">Checkout</Link>
        </nav>
      </div>
    </header>
  )
}
