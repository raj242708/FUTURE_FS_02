# Next.js Final Shop
- Home page: hero text + **all products grid** (no categories).
- Uses your uploaded images renamed to realistic product names.
- Cart, Checkout, Success pages included. LocalStorage persists cart.
- Tech: Next.js (pages router) + Tailwind CSS.

## Run
npm install
npm run dev
# open http://localhost:3000

Built: 2025-09-01T13:49:06.142612Z
Products: 10
