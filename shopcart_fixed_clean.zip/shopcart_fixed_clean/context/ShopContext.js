import { createContext, useEffect, useMemo, useState } from 'react'
import { products as allProducts } from '../data/products'

export const ShopContext = createContext()

export function ShopProvider({ children }) {
  const [cart, setCart] = useState([])

  useEffect(() => {
    try {
      if (typeof window === 'undefined') return
      const raw = localStorage.getItem('cart')
      if (raw) setCart(JSON.parse(raw))
    } catch {}
  }, [])

  useEffect(() => {
    try {
      if (typeof window === 'undefined') return
      localStorage.setItem('cart', JSON.stringify(cart))
    } catch {}
  }, [cart])

  const addToCart = (product) => {
    setCart(prev => {
      const exist = prev.find(p => p.id === product.id)
      if (exist) return prev.map(p => p.id === product.id ? { ...p, qty: (p.qty || 1) + 1 } : p)
      return [...prev, { ...product, qty: 1 }]
    })
  }
  const removeFromCart = (id) => setCart(prev => prev.filter(p => p.id !== id))
  const setQty = (id, qty) => setCart(prev => prev.map(p => p.id === id ? { ...p, qty: Math.max(1, qty) } : p))
  const clearCart = () => setCart([])

  const total = useMemo(() => cart.reduce((s, i) => s + i.price * (i.qty || 1), 0), [cart])

  return (
    <ShopContext.Provider value={{ cart, addToCart, removeFromCart, setQty, clearCart, total, products: allProducts }}>
      {children}
    </ShopContext.Provider>
  )
}
