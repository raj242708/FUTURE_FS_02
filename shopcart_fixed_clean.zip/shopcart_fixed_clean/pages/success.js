import Link from 'next/link'
export default function Success() {
  return (
    <div className="text-center py-20">
      <h1 className="text-3xl font-bold">🎉 Order placed successfully!</h1>
      <p className="text-neutral-600 mt-2">Thank you for shopping with us.</p>
      <Link className="btn-primary mt-6" href="/">Continue Shopping</Link>
    </div>
  )
}
