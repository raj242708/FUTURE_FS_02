import { useContext } from 'react'
import { ShopContext } from '../context/ShopContext'

export default function Cart() {
  const { cart, removeFromCart, setQty, total } = useContext(ShopContext)
  if (!cart.length) return <div className="text-center py-20"><h1 className="text-2xl font-semibold">Your cart is empty</h1></div>
  return (
    <div className="grid md:grid-cols-[1fr,360px] gap-6">
      <div className="card p-4">
        {cart.map(item => (
          <div key={item.id} className="flex items-center gap-4 py-4 border-b last:border-0">
            <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded" />
            <div className="flex-1">
              <div className="font-medium">{item.name}</div>
              <div className="text-sm text-neutral-500">${item.price}</div>
            </div>
            <div className="flex items-center gap-2">
              <input type="number" min="1" className="w-16 rounded-lg border px-2 py-1" value={item.qty}
                onChange={(e) => setQty(item.id, Number(e.target.value))} />
              <button className="btn-outline" onClick={() => removeFromCart(item.id)}>Remove</button>
            </div>
          </div>
        ))}
      </div>
      <aside className="card p-4 h-fit sticky top-24">
        <h2 className="text-lg font-semibold mb-3">Order Summary</h2>
        <div className="flex justify-between py-1"><span>Subtotal</span><span>${total.toFixed(2)}</span></div>
        <div className="flex justify-between py-1"><span>Shipping</span><span>Free</span></div>
        <div className="flex justify-between py-2 border-t mt-2 font-semibold"><span>Total</span><span>${total.toFixed(2)}</span></div>
        <a href="/checkout" className="btn-primary w-full mt-3 text-center">Proceed to Checkout</a>
      </aside>
    </div>
  )
}
