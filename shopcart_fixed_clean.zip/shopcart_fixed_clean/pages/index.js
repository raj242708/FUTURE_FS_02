import { products } from '../data/products'
import ProductCard from '../components/ProductCard'

export default function Home() {
  return (
    <section className="space-y-6">
      <div className="card overflow-hidden">
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-8 md:p-12 grid md:grid-cols-2 items-center gap-6">
          <div>
            <p className="text-sm uppercase tracking-wide text-blue-700 font-semibold">Limited Offer</p>
            <h1 className="text-3xl md:text-4xl font-bold mt-1">Grab Up to 50% Off on Selected Headphones</h1>
            <p className="text-neutral-600 mt-2">Plus exclusive deals on sneakers, watches, backpacks & laptops.</p>
            <a href="#products" className="btn-primary mt-4 inline-block">Shop Now</a>
          </div>
          {/* No image per user request */}
        </div>
      </div>

      <div id="products">
        <h2 className="text-xl font-bold mb-3">Products For You</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {products.map(p => <ProductCard key={p.id} product={p} />)}
        </div>
      </div>
    </section>
  )
}
