import '../styles/globals.css'
import Navbar from '../components/Navbar'
import { ShopProvider } from '../context/ShopContext'

export default function App({ Component, pageProps }) {
  return (
    <ShopProvider>
      <Navbar />
      <main className="container py-6">
        <Component {...pageProps} />
      </main>
    </ShopProvider>
  );
}
