import { useContext } from 'react'
import { ShopContext } from '../context/ShopContext'
import { useRouter } from 'next/router'

export default function Checkout() {
  const { cart, clearCart } = useContext(ShopContext)
  const router = useRouter()
  const onSubmit = (e) => { e.preventDefault(); clearCart(); router.push('/success') }
  if (!cart.length) return <div className="text-center py-20"><h1 className="text-2xl font-semibold">Nothing to checkout</h1></div>
  return (
    <form onSubmit={onSubmit} className="card p-6 max-w-xl mx-auto grid gap-3">
      <h1 className="text-xl font-semibold">Checkout</h1>
      <input placeholder="Full Name" required className="rounded-lg border px-3 py-2" />
      <input placeholder="Email" type="email" required className="rounded-lg border px-3 py-2" />
      <input placeholder="Address" required className="rounded-lg border px-3 py-2" />
      <select className="rounded-lg border px-3 py-2">
        <option>Cash on Delivery</option>
        <option>Card</option>
        <option>UPI</option>
      </select>
      <button className="btn-primary mt-2" type="submit">Place Order</button>
    </form>
  )
}
